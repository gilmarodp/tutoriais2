<?php

// FrontController, única entrada para o aplicativo
require_once __DIR__ . '/../core/bootstrap.php';

