Arquivos de view todos com extensão .phtml
